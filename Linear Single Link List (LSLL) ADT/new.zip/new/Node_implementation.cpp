#include"Node.cpp"
template class Node<int>;