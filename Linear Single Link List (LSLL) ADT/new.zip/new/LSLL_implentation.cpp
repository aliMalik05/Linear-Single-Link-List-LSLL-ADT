#include"LSLL.cpp"
template class LSLL<int>;